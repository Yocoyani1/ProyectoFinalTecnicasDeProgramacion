from distutils.core import setup

setup(
    name="Proyecto",
    version="0.1 dev",
    packages=['proyecto',],
    license='MIT',
    long_description=open('README.txt').read(),

)
