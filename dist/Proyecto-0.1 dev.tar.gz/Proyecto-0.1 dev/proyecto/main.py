import Menu as mn
import funciones as fc

def main():
	fc.crearBases()
	mn.Menu.correr()

main()